# Software Engineering Assignment 2
# Rohit Ranjan
# 20CS30066

g++ -Wall assgn2.cpp utils.cpp
./a.out