// Software Engineering Assignment 2
// Rohit Ranjan
// 20CS30066

Run Instructions:

$ bash ./compile_run.sh